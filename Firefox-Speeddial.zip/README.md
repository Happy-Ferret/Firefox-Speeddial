# Firefox-Speeddial
Opera style speed dial front page for Firefox
